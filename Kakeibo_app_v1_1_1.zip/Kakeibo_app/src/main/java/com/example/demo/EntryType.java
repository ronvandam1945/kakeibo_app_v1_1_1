package com.example.demo;

public enum EntryType {
    INCOME,   // 収入
    EXPENSE   // 支出
}