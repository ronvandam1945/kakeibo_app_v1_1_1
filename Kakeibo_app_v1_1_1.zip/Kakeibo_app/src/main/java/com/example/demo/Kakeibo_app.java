package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kakeibo_app {

	public static void main(String[] args) {
		SpringApplication.run(Kakeibo_app.class, args);
	}

}
